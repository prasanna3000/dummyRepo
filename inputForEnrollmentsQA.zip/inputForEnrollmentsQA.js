// ***********************************************************
// Course Details:-
// Title: "Course for Enrollments"
// createdAt : 1472795462000.0, (Friday, September 2, 2016 - 11:21:02)
// -----------------------------------------------------------
// -----------------------------------------------------------
// Candidate Details:-
// 1. kyle kobe              ObjectId("5fdb3cdf810ed35ba8e24361")        (5 years ago)
// 2. k walker               ObjectId("5fdb3ce1810ed35ba8e2436f")        (4 years ago)
// 3. aj price               ObjectId("5fdb3ce3810ed35ba8e2438b")        (3 years ago)
// 4. aaron brooks           ObjectId("5fdb3ce4810ed35ba8e24399")        (2 years ago)
// 5. aaron gordon           ObjectId("5fdb3ce5810ed35ba8e243a7")        (year ago)
// 6. adreian payne          ObjectId("5fdb3ce6810ed35ba8e243b5")        (year ago)
// 7. al horford             ObjectId("5fdb3ce7810ed35ba8e243c3")        (9 months ago)
// 8. al jefferson           ObjectId("5fdb3ce8810ed35ba8e243d1")        (7 months ago)
// 9. alan anderson          ObjectId("5fdb3cea810ed35ba8e243df")        (6 months ago)
// 10. alec burks            ObjectId("5fdb3ceb810ed35ba8e243ed")        (4 months ago)
// 11. alex kirk             ObjectId("5fdb3cec810ed35ba8e243fb")        (3 months ago)
// 12. alex len              ObjectId("5fdb3cf0810ed35ba8e24409")        (3 months ago)
// 13. alexey shved          ObjectId("5fdb3cf1810ed35ba8e24417")        (a month ago)
// 14. alexis ajinca         ObjectId("5fdb3cf2810ed35ba8e24425")        (20 days ago)
// 15. prasanna              ObjectId("604b59679319c415ec9b19db")        (14 days ago)
// 16. prasanna              ObjectId("60b8a753eb6d7f8ba4fee006")        (5 days ago)
// 17. prasanna              ObjectId("60b8a7b3eb6d7f8ba4fee040")        (2 days ago)
// 18. karan                 ObjectId("60d441c1728f89bf28eb558e")        (today)
// 19. rajjev3               ObjectId("60d441c3728f89bf28eb55b6")        (today)               
const listOfCandidateUserIds = [
    ObjectId("5f7531eef0c20a120bf814a1"),
    ObjectId("5f7531eff0c20a120bf814af"),
    ObjectId("5f7531eff0c20a120bf814bd"),
    ObjectId("5f755e07f0c20a120bf81840"),
    ObjectId("5f756da6f0c20a120bf81b31"),
    ObjectId("5f756f24f0c20a120bf81b5d"),
    ObjectId("5f757d07f0c20a120bf81c27"),
    ObjectId("5f7c1bf586bbe337ec2bd067"),
    ObjectId("5f7c1bf686bbe337ec2bd075"),
    ObjectId("5f7ecfdd9e54610963677eda"),
    ObjectId("5f8066249e546109636783f2"),
    ObjectId("5f80666a9e5461096367843d"),
    ObjectId("5f80666b9e5461096367844b"),
    ObjectId("5f80666c9e54610963678459"),
    ObjectId("5f80666d9e54610963678467"),
    ObjectId("5f80666e9e54610963678475"),
    ObjectId("5f80666f9e54610963678483"),
    ObjectId("5f80666f9e54610963678491"),
    ObjectId("5f8066709e5461096367849f")
];

// const milliSecondsForADay = 86400000;

// const upperLimitForTS = 1631860200000;
// const loweLimitForTS = 1472884200000;

// const candidateNamesForSubscription = [
//     'kyle kobe',
//     'k walker',
//     'aj price',
//     'aaron brooks',
//     'aaron gordon',
//     'adreian payne',
//     'al horford',
//     'al jefferson',
//     'alan anderson',
//     'alec burks',
//     'alex kirk',
//     'alex len',
//     'alexey shved',
//     'alexis ajinca',
//     'prasanna',
//     'prasanna',
//     'prasanna',
//     'karan',
//     'rajjev3',
// ];
const frequencyOfRegistrations = [
    1,2,3,4,6,7,8,9,10,12,13,14,15,16,17,19, 20
];
const timeStampsForTs = [
    1474230600000,
    1505766600000,
    1537302600000,
    1568838600000,
    1600461000000,
    1608323400000,
    1613680200000,
    1616099400000,
    1621369800000,
    1624048200000,
    1629318600000,
    1630269000000,
    1630787400000,
    1631565000000,
    1631824200000,
    1631997000000,
    1632342600000,
];


const timeStampsForSubscription = [
    1474152590000, // Sunday, September 18, 2016 (4:19:50)
    1505742015000, // Monday, September 18, 2017 (19:10:15)
    1537215600000, // Tuesday, September 18, 2018 (1:50:00)
    1568785862000, // Wednesday, September 18, 2019 (11:21:02)
    1600399905000, // Friday, September 18, 2020 (09:01:45)
    1600435905000, // Friday, September 18, 2020 (19:01:45)
    1608234832000, // Friday, December 18, 2020 (1:23:52)
    1613644205000, // Thursday, February 18, 2021 (16:00:05)
    1616019845000, // Thursday, March 18, 2021 (3:54:5)
    1621323295000, // Tuesday, May 18, 2021 (13:04:55)
    1624005845000, // Friday, June 18, 2021 (14:14:05)
    1624005965000, // Friday, June 18, 2021 (14:16:05)
    1629239765000, // Wednesday, August 18, 2021 (04:06:05)
    1630241165000, // Sunday, August 29, 2021 (18:16:05)
    1630722601000, // Saturday, September 4, 2021 (08:00:01)
    1631536201000, // Monday, September 13, 2021 (18:00:01)
    1631765086000, // Thursday, September 16, 2021 (09:34:46)
    1631974281377, // Saturday, September 18, 2021 (1:41:21)
    1631974326435, // Saturday, September 18, 2021 (1:41:06)
    1632285000000, // Wednesday, September 22, 2021 (10:00:00)
];
// const courseId = ObjectId("607925c6d02bc4634c4d7b89");
const mentorUserId = ObjectId("60e29285211eb80b7912aeb0"); // Aprajitha

const courseDetails = {
    skillTags : [ 
        ObjectId("60b8c1733c96d931016078a3")
    ],
    exercises : [ 
        ObjectId("60e29fa9211eb80b7912aef1"),
        ObjectId("60e2a18c211eb80b7912aefd")
    ],
    allowNewRegistrations : true,
    allowDiscussions : false,
    publishedUnder : "name",
    version : 1,
    title : "DUMMY COURSE On Sep-2, 2016",
    description : "<p>AWS is a cloud computing service offered by Amazon. AWS lets you build, test, deploy and manage applications and services. All this is done via the data-centers and the hardware managed by Amazon. AWS provides you a combination of Infrastructure-as-a-Service (IaaS), Platform-as-a-Service (PaaS), and Software-as-a-Service (SaaS) offerings.</p>\n<p>You can use AWS to create Virtual Machines which can be armed with processing power, storage capacity, and analytics along with networking and device management. AWS offers you a pay-as-you-go model, which helps to avoid upfront costs and pay based on the usage monthly.</p>",
    credits : 0,
    estimatedCredits : 0,
    ownerUserId : ObjectId("60e29285211eb80b7912aeb0"),
    attemptSequence : "SEQUENTIAL",
    createdAt : 1472795462000.0,
    updatedAt : 1472795462000.0,
};

const startingTimeStampForTs = 1474230600000; // day from when record getting inserted in the scheduler, it is based on first registration happened in the course
